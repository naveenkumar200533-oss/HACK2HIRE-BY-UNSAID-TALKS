import { pgTable, text, serial, integer, boolean, timestamp, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";
import { relations } from "drizzle-orm";
import { users } from "./models/auth"; // Import users from auth module

// Re-export auth models
export * from "./models/auth";
// Re-export chat models (if needed, though we might not use them directly for interviews)
export * from "./models/chat";

// === TABLE DEFINITIONS ===

// Interviews table - tracks interview sessions
export const interviews = pgTable("interviews", {
  id: serial("id").primaryKey(),
  userId: text("user_id").notNull(), // Foreign key to auth.users.id (which is varchar)
  jobDescription: text("job_description").notNull(),
  resumeText: text("resume_text").notNull(), // Extracted text from resume
  resumeUrl: text("resume_url").notNull(), // URL to file in object storage
  status: text("status", { enum: ["in_progress", "completed"] }).default("in_progress").notNull(),
  score: integer("score"), // Overall score 0-100
  feedback: jsonb("feedback"), // Structured feedback object
  createdAt: timestamp("created_at").defaultNow(),
});

// Questions table - questions generated for an interview
export const questions = pgTable("questions", {
  id: serial("id").primaryKey(),
  interviewId: integer("interview_id").notNull().references(() => interviews.id),
  text: text("text").notNull(),
  difficulty: text("difficulty", { enum: ["easy", "medium", "hard"] }).notNull(),
  order: integer("order").notNull(),
  userAnswer: text("user_answer"), // Text transcript of answer
  userAudioUrl: text("user_audio_url"), // Optional audio recording
  aiFeedback: text("ai_feedback"), // Specific feedback for this question
  score: integer("score"), // Score for this specific answer 0-100
  createdAt: timestamp("created_at").defaultNow(),
});

// === RELATIONS ===
export const interviewsRelations = relations(interviews, ({ many }) => ({
  questions: many(questions),
}));

export const questionsRelations = relations(questions, ({ one }) => ({
  interview: one(interviews, {
    fields: [questions.interviewId],
    references: [interviews.id],
  }),
}));

// === BASE SCHEMAS ===
export const insertInterviewSchema = createInsertSchema(interviews).omit({ 
  id: true, 
  createdAt: true, 
  score: true, 
  feedback: true,
  status: true
});

export const insertQuestionSchema = createInsertSchema(questions).omit({ 
  id: true, 
  createdAt: true,
  userAnswer: true,
  userAudioUrl: true,
  aiFeedback: true,
  score: true
});

// === EXPLICIT API CONTRACT TYPES ===

// Base types
export type Interview = typeof interviews.$inferSelect;
export type InsertInterview = z.infer<typeof insertInterviewSchema>;
export type Question = typeof questions.$inferSelect;
export type InsertQuestion = z.infer<typeof insertQuestionSchema>;

// Request types
export type CreateInterviewRequest = InsertInterview;

export type SubmitAnswerRequest = {
  answerText: string;
  audioUrl?: string;
};

// Response types
export type InterviewWithQuestions = Interview & {
  questions: Question[];
};

export type InterviewResponse = Interview;
export type QuestionResponse = Question;

// Feedback type structure
export interface InterviewFeedback {
  strengths: string[];
  weaknesses: string[];
  improvements: string[];
  overallSummary: string;
}
