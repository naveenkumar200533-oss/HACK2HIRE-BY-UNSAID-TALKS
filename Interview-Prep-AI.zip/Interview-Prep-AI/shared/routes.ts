import { z } from 'zod';
import { insertInterviewSchema, interviews, questions } from './schema';

// ============================================
// SHARED ERROR SCHEMAS
// ============================================
export const errorSchemas = {
  validation: z.object({
    message: z.string(),
    field: z.string().optional(),
  }),
  notFound: z.object({
    message: z.string(),
  }),
  internal: z.object({
    message: z.string(),
  }),
  unauthorized: z.object({
    message: z.string(),
  })
};

// ============================================
// API CONTRACT
// ============================================
export const api = {
  interviews: {
    create: {
      method: 'POST' as const,
      path: '/api/interviews',
      input: insertInterviewSchema,
      responses: {
        201: z.custom<typeof interviews.$inferSelect>(), // Returns created interview
        400: errorSchemas.validation,
        401: errorSchemas.unauthorized
      },
    },
    list: {
      method: 'GET' as const,
      path: '/api/interviews',
      responses: {
        200: z.array(z.custom<typeof interviews.$inferSelect>()),
        401: errorSchemas.unauthorized
      },
    },
    get: {
      method: 'GET' as const,
      path: '/api/interviews/:id',
      responses: {
        200: z.custom<typeof interviews.$inferSelect & { questions: typeof questions.$inferSelect[] }>(),
        404: errorSchemas.notFound,
        401: errorSchemas.unauthorized
      },
    },
    generateQuestions: { // Trigger AI generation
      method: 'POST' as const,
      path: '/api/interviews/:id/generate',
      responses: {
        200: z.array(z.custom<typeof questions.$inferSelect>()),
        404: errorSchemas.notFound,
        401: errorSchemas.unauthorized
      }
    },
    submitAnswer: {
      method: 'POST' as const,
      path: '/api/questions/:id/answer',
      input: z.object({
        answerText: z.string(),
        audioUrl: z.string().optional()
      }),
      responses: {
        200: z.custom<typeof questions.$inferSelect>(), // Returns updated question with feedback
        404: errorSchemas.notFound,
        401: errorSchemas.unauthorized
      }
    },
    finalize: { // Complete interview and generate final report
      method: 'POST' as const,
      path: '/api/interviews/:id/finalize',
      responses: {
        200: z.custom<typeof interviews.$inferSelect>(),
        404: errorSchemas.notFound,
        401: errorSchemas.unauthorized
      }
    }
  },
};

// ============================================
// HELPER: buildUrl
// ============================================
export function buildUrl(path: string, params?: Record<string, string | number>): string {
  let url = path;
  if (params) {
    Object.entries(params).forEach(([key, value]) => {
      if (url.includes(`:${key}`)) {
        url = url.replace(`:${key}`, String(value));
      }
    });
  }
  return url;
}

// ============================================
// TYPE HELPERS
// ============================================
export type CreateInterviewInput = z.infer<typeof api.interviews.create.input>;
export type SubmitAnswerInput = z.infer<typeof api.interviews.submitAnswer.input>;
