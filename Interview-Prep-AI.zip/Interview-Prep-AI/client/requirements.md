## Packages
framer-motion | Smooth page transitions and component animations
recharts | Data visualization for interview scores
react-circular-progressbar | Score visualization rings
pdfjs-dist | Extract text from PDF resumes on the client side
mammoth | Extract text from DOCX resumes on the client side
clsx | Utility for conditional classes
tailwind-merge | Utility for merging tailwind classes

## Notes
- Using Replit Auth for authentication
- Using Replit Object Storage for resume hosting
- Using Replit AI integration hooks for Voice (if available) or falling back to standard inputs
- PDF/DOCX text extraction happens on client to satisfy `resumeText` schema requirement
