import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { api, buildUrl } from "@shared/routes";
import { useToast } from "@/hooks/use-toast";
import type { 
  CreateInterviewInput, 
  SubmitAnswerInput,
  InterviewWithQuestions
} from "@shared/routes";

export function useInterviews() {
  const { toast } = useToast();

  return useQuery({
    queryKey: [api.interviews.list.path],
    queryFn: async () => {
      const res = await fetch(api.interviews.list.path, { credentials: "include" });
      if (res.status === 401) return null;
      if (!res.ok) throw new Error("Failed to fetch interviews");
      return api.interviews.list.responses[200].parse(await res.json());
    },
  });
}

export function useInterview(id: number) {
  return useQuery({
    queryKey: [api.interviews.get.path, id],
    queryFn: async () => {
      const url = buildUrl(api.interviews.get.path, { id });
      const res = await fetch(url, { credentials: "include" });
      if (res.status === 404) return null;
      if (!res.ok) throw new Error("Failed to fetch interview");
      return api.interviews.get.responses[200].parse(await res.json());
    },
    enabled: !!id,
  });
}

export function useCreateInterview() {
  const queryClient = useQueryClient();
  const { toast } = useToast();

  return useMutation({
    mutationFn: async (data: CreateInterviewInput) => {
      const res = await fetch(api.interviews.create.path, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
        credentials: "include",
      });

      if (!res.ok) {
        if (res.status === 400) {
          const error = await res.json();
          throw new Error(error.message || "Invalid data");
        }
        throw new Error("Failed to create interview");
      }
      return api.interviews.create.responses[201].parse(await res.json());
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [api.interviews.list.path] });
      toast({
        title: "Interview Created",
        description: "Your session is being prepared.",
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    },
  });
}

export function useGenerateQuestions() {
  const queryClient = useQueryClient();
  const { toast } = useToast();

  return useMutation({
    mutationFn: async (interviewId: number) => {
      const url = buildUrl(api.interviews.generateQuestions.path, { id: interviewId });
      const res = await fetch(url, { 
        method: "POST", 
        credentials: "include" 
      });
      
      if (!res.ok) throw new Error("Failed to generate questions");
      return api.interviews.generateQuestions.responses[200].parse(await res.json());
    },
    onSuccess: (_, interviewId) => {
      queryClient.invalidateQueries({ queryKey: [api.interviews.get.path, interviewId] });
      toast({
        title: "Questions Ready",
        description: "Your AI interviewer is ready to begin.",
      });
    },
  });
}

export function useSubmitAnswer() {
  const queryClient = useQueryClient();
  const { toast } = useToast();

  return useMutation({
    mutationFn: async ({ questionId, ...data }: SubmitAnswerInput & { questionId: number }) => {
      const url = buildUrl(api.interviews.submitAnswer.path, { id: questionId });
      const res = await fetch(url, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
        credentials: "include",
      });

      if (!res.ok) throw new Error("Failed to submit answer");
      return api.interviews.submitAnswer.responses[200].parse(await res.json());
    },
    onSuccess: (data) => {
      // Invalidate the interview query to refresh the question list state
      queryClient.invalidateQueries({ queryKey: [api.interviews.get.path] });
    },
  });
}

export function useFinalizeInterview() {
  const queryClient = useQueryClient();
  const { toast } = useToast();

  return useMutation({
    mutationFn: async (interviewId: number) => {
      const url = buildUrl(api.interviews.finalize.path, { id: interviewId });
      const res = await fetch(url, { 
        method: "POST", 
        credentials: "include" 
      });
      
      if (!res.ok) throw new Error("Failed to finalize interview");
      return api.interviews.finalize.responses[200].parse(await res.json());
    },
    onSuccess: (_, interviewId) => {
      queryClient.invalidateQueries({ queryKey: [api.interviews.list.path] });
      queryClient.invalidateQueries({ queryKey: [api.interviews.get.path, interviewId] });
      toast({
        title: "Interview Completed",
        description: "Your results are ready.",
      });
    },
  });
}
