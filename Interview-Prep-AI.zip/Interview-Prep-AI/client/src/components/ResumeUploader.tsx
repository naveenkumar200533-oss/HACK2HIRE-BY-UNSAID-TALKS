import { useState } from "react";
import { ObjectUploader } from "@/components/ObjectUploader";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { FileText, CheckCircle, AlertCircle, Loader2 } from "lucide-react";
import { extractTextFromFile } from "@/lib/file-utils";

interface ResumeUploaderProps {
  onUploadComplete: (url: string, text: string) => void;
  className?: string;
}

export function ResumeUploader({ onUploadComplete, className }: ResumeUploaderProps) {
  const [status, setStatus] = useState<"idle" | "extracting" | "done" | "error">("idle");
  const [fileName, setFileName] = useState<string>("");

  return (
    <Card className={`border-dashed border-2 bg-muted/30 ${className}`}>
      <CardContent className="flex flex-col items-center justify-center py-10 px-4 text-center">
        {status === "idle" && (
          <div className="space-y-4">
            <div className="w-16 h-16 bg-primary/10 text-primary rounded-full flex items-center justify-center mx-auto mb-4">
              <FileText className="w-8 h-8" />
            </div>
            <h3 className="text-lg font-semibold">Upload Your Resume</h3>
            <p className="text-sm text-muted-foreground max-w-xs mx-auto">
              We support PDF and DOCX formats. We'll analyze your skills to tailor the interview.
            </p>
            
            <ObjectUploader
              onGetUploadParameters={async (file) => {
                setFileName(file.name);
                setStatus("extracting");
                
                // Extract text immediately before getting upload URL
                // Note: Uppy passes us a file object wrapper, we need the actual blob/file
                // Usually file.data is the Blob/File in Uppy
                const actualFile = file.data as File;
                
                try {
                  const text = await extractTextFromFile(actualFile);
                  // Store text temporarily in a closure or state if needed, 
                  // but we pass it up in onComplete.
                  // For now, we attach it to the file object to retrieve later
                  (file as any).extractedText = text;
                } catch (e) {
                  console.error("Extraction failed", e);
                  setStatus("error");
                  throw e;
                }

                // Standard presigned URL flow
                const res = await fetch("/api/uploads/request-url", {
                  method: "POST",
                  headers: { "Content-Type": "application/json" },
                  body: JSON.stringify({
                    name: file.name,
                    size: file.size,
                    contentType: file.type,
                  }),
                });
                const { uploadURL } = await res.json();
                return {
                  method: "PUT",
                  url: uploadURL,
                  headers: { "Content-Type": file.type },
                };
              }}
              onComplete={(result) => {
                const successful = result.successful[0];
                if (successful) {
                  const url = successful.uploadURL;
                  const text = (successful as any).extractedText || ""; 
                  // Note: Uppy might not persist custom props on 'successful' array items easily.
                  // Ideally we extract text separately or rely on the closure scope if single file.
                  
                  // Safer approach: We extracted text in getUploadParameters. 
                  // In a real app we might want to decouple this, but for MVP:
                  if (url) {
                    setStatus("done");
                    onUploadComplete(url, text);
                  }
                }
              }}
            >
              <span className="flex items-center gap-2">
                Select Resume
              </span>
            </ObjectUploader>
          </div>
        )}

        {status === "extracting" && (
          <div className="space-y-4 animate-in fade-in">
            <Loader2 className="w-10 h-10 text-primary animate-spin mx-auto" />
            <p className="font-medium">Analyzing {fileName}...</p>
          </div>
        )}

        {status === "done" && (
          <div className="space-y-4 animate-in zoom-in-95">
            <div className="w-16 h-16 bg-green-100 text-green-600 rounded-full flex items-center justify-center mx-auto">
              <CheckCircle className="w-8 h-8" />
            </div>
            <div>
              <p className="font-semibold text-foreground">Ready to go!</p>
              <p className="text-sm text-muted-foreground">{fileName} uploaded successfully.</p>
            </div>
            <Button variant="outline" size="sm" onClick={() => setStatus("idle")}>
              Replace File
            </Button>
          </div>
        )}

        {status === "error" && (
          <div className="space-y-4">
            <div className="w-16 h-16 bg-red-100 text-red-600 rounded-full flex items-center justify-center mx-auto">
              <AlertCircle className="w-8 h-8" />
            </div>
            <p className="font-medium">Failed to process file</p>
            <Button variant="outline" onClick={() => setStatus("idle")}>
              Try Again
            </Button>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
