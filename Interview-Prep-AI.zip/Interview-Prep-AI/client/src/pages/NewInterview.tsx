import { useState } from "react";
import { useLocation } from "wouter";
import { useCreateInterview } from "@/hooks/use-interviews";
import { ResumeUploader } from "@/components/ResumeUploader";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { ChevronRight, Loader2 } from "lucide-react";
import { motion } from "framer-motion";

export default function NewInterview() {
  const [step, setStep] = useState(1);
  const [resumeData, setResumeData] = useState<{ url: string; text: string } | null>(null);
  const [jobDescription, setJobDescription] = useState("");
  const { mutate: createInterview, isPending } = useCreateInterview();
  const [, setLocation] = useLocation();

  const handleSubmit = () => {
    if (!resumeData || !jobDescription.trim()) return;

    createInterview(
      {
        resumeUrl: resumeData.url,
        resumeText: resumeData.text,
        jobDescription: jobDescription,
      },
      {
        onSuccess: (data) => {
          setLocation(`/interview/${data.id}`);
        },
      }
    );
  };

  return (
    <div className="max-w-3xl mx-auto py-8">
      <div className="mb-8">
        <h1 className="text-3xl font-display font-bold">New Interview Session</h1>
        <p className="text-muted-foreground">Let's set up the context for your AI interviewer.</p>
      </div>

      <div className="space-y-8">
        {/* Step 1: Resume */}
        <motion.div
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          className={step === 1 ? "block" : "hidden"}
        >
          <Card className="border-2 border-primary/10 shadow-lg">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <span className="flex items-center justify-center w-8 h-8 rounded-full bg-primary text-primary-foreground text-sm">1</span>
                Upload Resume
              </CardTitle>
            </CardHeader>
            <CardContent>
              <ResumeUploader 
                onUploadComplete={(url, text) => {
                  setResumeData({ url, text });
                  setStep(2);
                }} 
              />
            </CardContent>
          </Card>
        </motion.div>

        {/* Step 2: Job Description */}
        <motion.div
          initial={{ opacity: 0, x: 20 }}
          animate={step === 2 ? { opacity: 1, x: 0 } : { opacity: 0, x: 20 }}
          className={step === 2 ? "block" : "hidden"}
        >
          <Card className="border-2 border-primary/10 shadow-lg">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <span className="flex items-center justify-center w-8 h-8 rounded-full bg-primary text-primary-foreground text-sm">2</span>
                Job Description
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="jd">Paste the job description here</Label>
                <Textarea
                  id="jd"
                  placeholder="e.g. Senior React Developer at TechCorp..."
                  className="min-h-[200px] text-base p-4"
                  value={jobDescription}
                  onChange={(e) => setJobDescription(e.target.value)}
                />
              </div>
              <div className="flex justify-between pt-4">
                <Button variant="ghost" onClick={() => setStep(1)}>Back</Button>
                <Button 
                  onClick={handleSubmit} 
                  disabled={!jobDescription.trim() || isPending}
                  size="lg"
                  className="px-8 shadow-lg shadow-primary/25"
                >
                  {isPending ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" /> Creating...
                    </>
                  ) : (
                    <>
                      Start Interview <ChevronRight className="ml-2 h-4 w-4" />
                    </>
                  )}
                </Button>
              </div>
            </CardContent>
          </Card>
        </motion.div>
      </div>
    </div>
  );
}
