import { useParams } from "wouter";
import { useInterview } from "@/hooks/use-interviews";
import { CircularProgressbar, buildStyles } from 'react-circular-progressbar';
import 'react-circular-progressbar/dist/styles.css';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Accordion, AccordionItem, AccordionTrigger, AccordionContent } from "@/components/ui/accordion";
import { Badge } from "@/components/ui/badge";
import { Loader2, ThumbsUp, ThumbsDown, Target } from "lucide-react";
import { motion } from "framer-motion";

export default function Results() {
  const { id } = useParams<{ id: string }>();
  const { data: interview, isLoading } = useInterview(parseInt(id!));

  if (isLoading || !interview) return <div className="flex h-screen items-center justify-center"><Loader2 className="animate-spin" /></div>;

  const feedback = interview.feedback as any || { strengths: [], weaknesses: [], improvements: [], overallSummary: "No feedback generated." };
  const score = interview.score || 0;

  return (
    <div className="max-w-5xl mx-auto py-8 px-4 space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-700">
      <div className="text-center mb-12">
        <h1 className="text-4xl font-display font-bold mb-2">Interview Analysis</h1>
        <p className="text-muted-foreground">Here's how you performed.</p>
      </div>

      {/* Top Stats Section */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card className="col-span-1 md:col-span-1 border-primary/20 shadow-lg">
          <CardHeader>
            <CardTitle>Overall Score</CardTitle>
          </CardHeader>
          <CardContent className="flex justify-center py-6">
            <div className="w-40 h-40">
              <CircularProgressbar
                value={score}
                text={`${score}%`}
                styles={buildStyles({
                  pathColor: `rgba(99, 102, 241, ${score / 100})`,
                  textColor: '#1f2937',
                  trailColor: '#f3f4f6',
                })}
              />
            </div>
          </CardContent>
        </Card>

        <Card className="col-span-1 md:col-span-2">
          <CardHeader>
            <CardTitle>Executive Summary</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-lg leading-relaxed text-muted-foreground">
              {feedback.overallSummary}
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Strengths & Weaknesses Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <Card className="bg-green-50/50 border-green-100">
          <CardHeader className="flex flex-row items-center gap-2">
            <ThumbsUp className="w-5 h-5 text-green-600" />
            <CardTitle className="text-green-900">Key Strengths</CardTitle>
          </CardHeader>
          <CardContent>
            <ul className="space-y-2">
              {feedback.strengths?.map((item: string, i: number) => (
                <li key={i} className="flex items-start gap-2 text-green-800">
                  <span className="w-1.5 h-1.5 rounded-full bg-green-500 mt-2 flex-shrink-0" />
                  {item}
                </li>
              ))}
            </ul>
          </CardContent>
        </Card>

        <Card className="bg-red-50/50 border-red-100">
          <CardHeader className="flex flex-row items-center gap-2">
            <ThumbsDown className="w-5 h-5 text-red-600" />
            <CardTitle className="text-red-900">Areas for Improvement</CardTitle>
          </CardHeader>
          <CardContent>
            <ul className="space-y-2">
              {feedback.weaknesses?.map((item: string, i: number) => (
                <li key={i} className="flex items-start gap-2 text-red-800">
                  <span className="w-1.5 h-1.5 rounded-full bg-red-500 mt-2 flex-shrink-0" />
                  {item}
                </li>
              ))}
            </ul>
          </CardContent>
        </Card>
      </div>

      {/* Detailed Q&A Breakdown */}
      <div className="space-y-4">
        <h2 className="text-2xl font-bold font-display flex items-center gap-2">
          <Target className="w-6 h-6 text-primary" />
          Question Breakdown
        </h2>
        <Accordion type="single" collapsible className="w-full space-y-4">
          {interview.questions?.map((q, i) => (
            <AccordionItem key={q.id} value={`item-${i}`} className="border bg-card rounded-lg px-4">
              <AccordionTrigger className="hover:no-underline py-4">
                <div className="flex flex-col sm:flex-row text-left gap-4 w-full pr-4">
                  <Badge variant="outline" className="w-fit h-fit whitespace-nowrap">
                    Q{i + 1}
                  </Badge>
                  <div className="flex-1">
                    <p className="font-semibold">{q.text}</p>
                  </div>
                  <div className={`font-bold ${
                    (q.score || 0) >= 80 ? 'text-green-600' : (q.score || 0) >= 60 ? 'text-yellow-600' : 'text-red-600'
                  }`}>
                    {q.score}/100
                  </div>
                </div>
              </AccordionTrigger>
              <AccordionContent className="pt-2 pb-6 space-y-6">
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                  <div className="bg-muted/30 p-4 rounded-lg">
                    <h4 className="text-sm font-semibold mb-2 uppercase tracking-wide text-muted-foreground">Your Answer</h4>
                    <p className="text-foreground">{q.userAnswer || "No answer recorded."}</p>
                  </div>
                  <div className="bg-primary/5 p-4 rounded-lg border border-primary/10">
                    <h4 className="text-sm font-semibold mb-2 uppercase tracking-wide text-primary">AI Feedback</h4>
                    <p className="text-foreground">{q.aiFeedback || "No feedback generated."}</p>
                  </div>
                </div>
              </AccordionContent>
            </AccordionItem>
          ))}
        </Accordion>
      </div>
    </div>
  );
}
