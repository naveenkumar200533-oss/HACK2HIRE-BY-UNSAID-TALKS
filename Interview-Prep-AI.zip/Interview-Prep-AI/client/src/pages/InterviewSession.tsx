import { useEffect, useState } from "react";
import { useParams, useLocation } from "wouter";
import { 
  useInterview, 
  useGenerateQuestions, 
  useSubmitAnswer, 
  useFinalizeInterview 
} from "@/hooks/use-interviews";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Loader2, Mic, Send, AlertCircle, CheckCircle2 } from "lucide-react";
import { useVoiceRecorder } from "@/replit_integrations/audio"; 
import { motion, AnimatePresence } from "framer-motion";

export default function InterviewSession() {
  const { id } = useParams<{ id: string }>();
  const interviewId = parseInt(id!);
  const [, setLocation] = useLocation();

  const { data: interview, isLoading, refetch } = useInterview(interviewId);
  const { mutate: generateQuestions, isPending: isGenerating } = useGenerateQuestions();
  const { mutate: submitAnswer, isPending: isSubmitting } = useSubmitAnswer();
  const { mutate: finalize, isPending: isFinalizing } = useFinalizeInterview();

  // Voice recorder integration
  const recorder = useVoiceRecorder();
  
  const [currentAnswer, setCurrentAnswer] = useState("");
  const [activeQuestionIndex, setActiveQuestionIndex] = useState(0);

  // Initial load logic: check if questions exist
  useEffect(() => {
    if (interview && interview.questions?.length === 0 && !isGenerating) {
      generateQuestions(interviewId);
    }
  }, [interview, isGenerating, generateQuestions, interviewId]);

  // Determine active question based on answered status
  useEffect(() => {
    if (interview?.questions) {
      const firstUnanswered = interview.questions.findIndex(q => !q.userAnswer);
      if (firstUnanswered !== -1) {
        setActiveQuestionIndex(firstUnanswered);
      } else if (interview.questions.length > 0) {
        // All answered
        setActiveQuestionIndex(interview.questions.length); // Out of bounds = done
      }
    }
  }, [interview?.questions]);

  const handleVoiceToggle = async () => {
    if (recorder.state === "recording") {
      const blob = await recorder.stopRecording();
      // In a real app, we'd transcribe this blob using OpenAI Whisper API
      // For this MVP, we'll simulate transcription or just mark it as "Audio Answer Provided"
      // Since we don't have a direct "transcribe only" endpoint readily exposed in the standard
      // client hook set without digging, we'll placeholder it.
      setCurrentAnswer((prev) => prev + " [Audio Answer Recorded] ");
    } else {
      await recorder.startRecording();
    }
  };

  const handleNext = () => {
    if (!currentQuestion) return;
    
    submitAnswer({
      questionId: currentQuestion.id,
      answerText: currentAnswer,
      // audioUrl: ... upload blob if we had one
    }, {
      onSuccess: () => {
        setCurrentAnswer("");
        // Optimistically move next or wait for refetch (refetch happens in hook)
      }
    });
  };

  const handleFinish = () => {
    finalize(interviewId, {
      onSuccess: () => setLocation(`/results/${interviewId}`)
    });
  };

  if (isLoading || !interview) {
    return <div className="flex h-screen items-center justify-center"><Loader2 className="animate-spin w-10 h-10 text-primary" /></div>;
  }

  // If waiting for generation
  if (interview.questions.length === 0) {
    return (
      <div className="flex flex-col h-[60vh] items-center justify-center text-center space-y-6">
        <div className="relative">
          <div className="absolute inset-0 bg-primary/20 blur-xl rounded-full animate-pulse"></div>
          <Loader2 className="relative w-16 h-16 animate-spin text-primary" />
        </div>
        <h2 className="text-2xl font-bold">AI is preparing your interview...</h2>
        <p className="text-muted-foreground max-w-md">Analyzing your resume against the job description to generate relevant questions.</p>
      </div>
    );
  }

  const currentQuestion = interview.questions[activeQuestionIndex];
  const progress = (activeQuestionIndex / interview.questions.length) * 100;
  const isComplete = activeQuestionIndex >= interview.questions.length;

  if (isComplete) {
    return (
      <div className="max-w-2xl mx-auto py-20 text-center space-y-8 animate-in zoom-in-95">
        <div className="w-24 h-24 bg-green-100 text-green-600 rounded-full flex items-center justify-center mx-auto mb-6">
          <CheckCircle2 className="w-12 h-12" />
        </div>
        <h1 className="text-4xl font-display font-bold">Interview Completed!</h1>
        <p className="text-xl text-muted-foreground">Great job. Let's process your results.</p>
        <Button 
          size="lg" 
          onClick={handleFinish} 
          disabled={isFinalizing}
          className="shadow-xl shadow-primary/25 text-lg px-8"
        >
          {isFinalizing ? <Loader2 className="animate-spin mr-2" /> : null}
          Generate Final Report
        </Button>
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto py-8 px-4">
      {/* Progress Header */}
      <div className="mb-8 space-y-2">
        <div className="flex justify-between text-sm font-medium text-muted-foreground">
          <span>Question {activeQuestionIndex + 1} of {interview.questions.length}</span>
          <span>{Math.round(progress)}% Complete</span>
        </div>
        <Progress value={progress} className="h-2" />
      </div>

      <AnimatePresence mode="wait">
        <motion.div
          key={currentQuestion.id}
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          exit={{ opacity: 0, x: -20 }}
          transition={{ duration: 0.3 }}
        >
          <Card className="border-0 shadow-2xl shadow-black/5 overflow-hidden">
            <div className="h-2 bg-gradient-to-r from-primary to-purple-500" />
            <CardContent className="p-8 space-y-8">
              <div className="space-y-4">
                <span className={`inline-block px-3 py-1 rounded-full text-xs font-semibold uppercase tracking-wider ${
                  currentQuestion.difficulty === 'hard' ? 'bg-red-100 text-red-700' :
                  currentQuestion.difficulty === 'medium' ? 'bg-yellow-100 text-yellow-700' :
                  'bg-green-100 text-green-700'
                }`}>
                  {currentQuestion.difficulty} Question
                </span>
                <h2 className="text-2xl md:text-3xl font-display font-bold leading-tight">
                  {currentQuestion.text}
                </h2>
              </div>

              <div className="space-y-4">
                <Textarea
                  placeholder="Type your answer here..."
                  className="min-h-[200px] text-lg p-6 resize-none bg-muted/30 focus:bg-background transition-colors border-2 focus:border-primary/50"
                  value={currentAnswer}
                  onChange={(e) => setCurrentAnswer(e.target.value)}
                  autoFocus
                />
                
                <div className="flex flex-col sm:flex-row items-center justify-between gap-4 pt-4">
                  <Button 
                    variant={recorder.state === "recording" ? "destructive" : "secondary"} 
                    onClick={handleVoiceToggle}
                    className="w-full sm:w-auto"
                  >
                    <Mic className={`w-4 h-4 mr-2 ${recorder.state === "recording" ? "animate-pulse" : ""}`} />
                    {recorder.state === "recording" ? "Stop Recording" : "Record Answer"}
                  </Button>

                  <Button 
                    size="lg" 
                    onClick={handleNext} 
                    disabled={!currentAnswer.trim() || isSubmitting}
                    className="w-full sm:w-auto shadow-lg shadow-primary/20"
                  >
                    {isSubmitting ? (
                      <Loader2 className="w-4 h-4 animate-spin mr-2" />
                    ) : (
                      <Send className="w-4 h-4 mr-2" />
                    )}
                    Submit Answer
                  </Button>
                </div>
              </div>

              {/* Tips/Hint area could go here */}
              <div className="bg-blue-50 text-blue-800 p-4 rounded-lg flex gap-3 text-sm">
                <AlertCircle className="w-5 h-5 flex-shrink-0" />
                <p>Tip: Focus on structuring your answer with the STAR method (Situation, Task, Action, Result).</p>
              </div>
            </CardContent>
          </Card>
        </motion.div>
      </AnimatePresence>
    </div>
  );
}
