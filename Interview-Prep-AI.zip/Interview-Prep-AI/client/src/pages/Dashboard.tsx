import { useInterviews } from "@/hooks/use-interviews";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardHeader, CardTitle, CardDescription, CardContent } from "@/components/ui/card";
import { Plus, Clock, CheckCircle, ArrowRight, Loader2 } from "lucide-react";
import { format } from "date-fns";

export default function Dashboard() {
  const { data: interviews, isLoading } = useInterviews();

  if (isLoading) {
    return (
      <div className="flex h-[50vh] items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <div className="space-y-8 animate-in fade-in duration-500">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-display font-bold text-foreground">Dashboard</h1>
          <p className="text-muted-foreground mt-1">Track your progress and start new sessions.</p>
        </div>
        <Button asChild className="shadow-lg shadow-primary/20">
          <Link href="/new">
            <Plus className="w-4 h-4 mr-2" />
            New Interview
          </Link>
        </Button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {/* Create New Card (Empty State) */}
        {interviews?.length === 0 && (
          <Card className="col-span-full py-12 flex flex-col items-center justify-center text-center border-dashed">
            <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mb-4">
              <Plus className="w-8 h-8 text-primary" />
            </div>
            <h3 className="text-lg font-semibold mb-2">No interviews yet</h3>
            <p className="text-muted-foreground mb-6">Start your first mock interview to get feedback.</p>
            <Button asChild>
              <Link href="/new">Get Started</Link>
            </Button>
          </Card>
        )}

        {interviews?.map((interview) => (
          <Link key={interview.id} href={interview.status === 'completed' ? `/results/${interview.id}` : `/interview/${interview.id}`}>
            <Card className="h-full hover:shadow-xl hover:-translate-y-1 transition-all duration-300 cursor-pointer border-l-4 border-l-primary group">
              <CardHeader>
                <div className="flex justify-between items-start mb-2">
                  <span className={`px-2.5 py-0.5 rounded-full text-xs font-medium ${
                    interview.status === 'completed' 
                      ? 'bg-green-100 text-green-700' 
                      : 'bg-yellow-100 text-yellow-700'
                  }`}>
                    {interview.status === 'completed' ? 'Completed' : 'In Progress'}
                  </span>
                  <span className="text-xs text-muted-foreground">
                    {format(new Date(interview.createdAt!), "MMM d, yyyy")}
                  </span>
                </div>
                <CardTitle className="text-lg line-clamp-1">{interview.jobDescription.slice(0, 50)}...</CardTitle>
                <CardDescription className="line-clamp-2">
                  Role Description Mock Interview
                </CardDescription>
              </CardHeader>
              <CardContent>
                {interview.status === 'completed' && interview.score !== null ? (
                  <div className="flex items-center gap-2">
                    <div className="text-2xl font-bold text-primary">{interview.score}%</div>
                    <span className="text-sm text-muted-foreground">Overall Score</span>
                  </div>
                ) : (
                  <div className="flex items-center text-primary text-sm font-medium group-hover:underline">
                    Continue Session <ArrowRight className="w-4 h-4 ml-1" />
                  </div>
                )}
              </CardContent>
            </Card>
          </Link>
        ))}
      </div>
    </div>
  );
}
