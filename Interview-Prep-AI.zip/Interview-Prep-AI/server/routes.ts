import type { Express } from "express";
import type { Server } from "http";
import { storage } from "./storage";
import { api } from "@shared/routes";
import { z } from "zod";
import { setupAuth, registerAuthRoutes } from "./replit_integrations/auth";
import { registerObjectStorageRoutes, ObjectStorageService } from "./replit_integrations/object_storage";
import { openai } from "./replit_integrations/audio/client"; // Reuse OpenAI client from integrations

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  // 1. Setup Auth
  await setupAuth(app);
  registerAuthRoutes(app);

  // 2. Setup Object Storage
  registerObjectStorageRoutes(app);

  // 3. API Routes

  // List Interviews
  app.get(api.interviews.list.path, async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    const userId = (req.user as any).claims.sub;
    const interviews = await storage.getUserInterviews(userId);
    res.json(interviews);
  });

  // Create Interview
  app.post(api.interviews.create.path, async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    const userId = (req.user as any).claims.sub;

    try {
      const input = api.interviews.create.input.parse(req.body);
      
      // Read resume text from Object Storage (if it's a text file or we can parse it)
      // For MVP, we might assume the client extracted text or we just use placeholder
      // For a real app, we'd need a PDF parser here.
      // Let's assume for MVP the resumeText is passed or we just use the description + resume URL content later.
      // The schema expects resumeText. If client can't extract, we might need to do it server side.
      // Let's assume the client sends resumeText if they can, or we fetch it.
      // Actually, standard browsers can't easily parse PDF.
      // Let's fetch the file content if it's text, otherwise just put a placeholder "Resume content at [url]"
      // so OpenAI can try to read it if we pass the URL (but OpenAI file search is not available in standard chat).
      // Optimization: We will just store the resumeUrl and a placeholder text if not provided.
      
      const interview = await storage.createInterview({
        ...input,
        userId,
        resumeText: input.resumeText || "Resume text extraction pending...", 
      });

      res.status(201).json(interview);
    } catch (err) {
      if (err instanceof z.ZodError) {
        return res.status(400).json({ message: err.errors[0].message });
      }
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // Get Interview
  app.get(api.interviews.get.path, async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    const interview = await storage.getInterview(Number(req.params.id));
    if (!interview) return res.status(404).json({ message: "Not found" });
    
    // Check ownership
    const userId = (req.user as any).claims.sub;
    if (interview.userId !== userId) return res.sendStatus(403);

    const questions = await storage.getQuestionsByInterviewId(interview.id);
    res.json({ ...interview, questions });
  });

  // Generate Questions (AI)
  app.post(api.interviews.generateQuestions.path, async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    const interviewId = Number(req.params.id);
    const interview = await storage.getInterview(interviewId);
    if (!interview) return res.status(404).json({ message: "Not found" });

    // Generate questions using OpenAI
    try {
      const prompt = `
        Role: Expert Technical Interviewer.
        Context: I am interviewing for a job.
        Job Description: ${interview.jobDescription}
        
        Task: Generate 5 interview questions.
        - Mix of behavioral and technical.
        - Difficulty levels: 2 easy, 2 medium, 1 hard.
        
        Return JSON format:
        [
          { "text": "Question text...", "difficulty": "easy" | "medium" | "hard" }
        ]
      `;

      const completion = await openai.chat.completions.create({
        model: "gpt-5.2",
        messages: [{ role: "user", content: prompt }],
        response_format: { type: "json_object" },
      });

      const result = JSON.parse(completion.choices[0].message.content || "{\"questions\": []}");
      const questionsData = result.questions || result; // Handle both {questions: [...]} and [...]

      const createdQuestions = [];
      let order = 1;
      for (const q of questionsData) {
        const newQ = await storage.createQuestion({
          interviewId: interview.id,
          text: q.text,
          difficulty: q.difficulty,
          order: order++,
        });
        createdQuestions.push(newQ);
      }

      res.json(createdQuestions);
    } catch (error) {
      console.error("AI Generation failed:", error);
      res.status(500).json({ message: "Failed to generate questions" });
    }
  });

  // Submit Answer & Get Feedback (AI)
  app.post(api.interviews.submitAnswer.path, async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    const questionId = Number(req.params.id);
    const question = await storage.getQuestion(questionId);
    if (!question) return res.status(404).json({ message: "Not found" });

    const { answerText } = req.body;

    // Evaluate answer with AI
    try {
      const prompt = `
        Question: ${question.text}
        Candidate Answer: ${answerText}
        
        Task: Evaluate this answer.
        - Provide a score (0-100).
        - Provide brief, actionable feedback (2-3 sentences).
        
        Return JSON:
        { "score": number, "feedback": "string" }
      `;

      const completion = await openai.chat.completions.create({
        model: "gpt-5.2",
        messages: [{ role: "user", content: prompt }],
        response_format: { type: "json_object" },
      });

      const evaluation = JSON.parse(completion.choices[0].message.content || "{}");

      const updatedQuestion = await storage.updateQuestion(questionId, {
        userAnswer: answerText,
        score: evaluation.score || 0,
        aiFeedback: evaluation.feedback || "No feedback generated.",
      });

      res.json(updatedQuestion);
    } catch (error) {
      console.error("AI Evaluation failed:", error);
      res.status(500).json({ message: "Failed to evaluate answer" });
    }
  });

  // Finalize Interview
  app.post(api.interviews.finalize.path, async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    const interviewId = Number(req.params.id);
    const interview = await storage.getInterview(interviewId);
    if (!interview) return res.status(404).json({ message: "Not found" });

    const questions = await storage.getQuestionsByInterviewId(interviewId);
    
    // Calculate overall score
    const totalScore = questions.reduce((sum, q) => sum + (q.score || 0), 0);
    const avgScore = Math.round(totalScore / (questions.length || 1));

    // Generate summary feedback
    try {
      const qnaLog = questions.map(q => `Q: ${q.text}\nA: ${q.userAnswer}\nFeedback: ${q.aiFeedback}`).join("\n\n");
      
      const prompt = `
        Review this interview session:
        ${qnaLog}
        
        Task: Provide a final summary.
        - List 3 key strengths.
        - List 3 key weaknesses.
        - List 3 specific improvements.
        - Overall summary paragraph.
        
        Return JSON:
        {
          "strengths": ["..."],
          "weaknesses": ["..."],
          "improvements": ["..."],
          "overallSummary": "..."
        }
      `;

      const completion = await openai.chat.completions.create({
        model: "gpt-5.2",
        messages: [{ role: "user", content: prompt }],
        response_format: { type: "json_object" },
      });

      const feedback = JSON.parse(completion.choices[0].message.content || "{}");

      const updatedInterview = await storage.updateInterview(interviewId, {
        status: "completed",
        score: avgScore,
        feedback: feedback,
      });

      res.json(updatedInterview);
    } catch (error) {
      console.error("Finalization failed:", error);
      res.status(500).json({ message: "Failed to finalize interview" });
    }
  });

  return httpServer;
}
