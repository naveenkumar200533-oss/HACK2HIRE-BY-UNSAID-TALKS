import { users, interviews, questions } from "@shared/schema";
import { db } from "./db";
import { eq, desc } from "drizzle-orm";
import type { InsertInterview, InsertQuestion } from "@shared/schema";

export interface IStorage {
  // Interviews
  createInterview(interview: InsertInterview): Promise<typeof interviews.$inferSelect>;
  getInterview(id: number): Promise<(typeof interviews.$inferSelect) | undefined>;
  getUserInterviews(userId: string): Promise<(typeof interviews.$inferSelect)[]>;
  updateInterview(id: number, updates: Partial<typeof interviews.$inferSelect>): Promise<typeof interviews.$inferSelect>;

  // Questions
  createQuestion(question: InsertQuestion): Promise<typeof questions.$inferSelect>;
  getQuestionsByInterviewId(interviewId: number): Promise<(typeof questions.$inferSelect)[]>;
  getQuestion(id: number): Promise<(typeof questions.$inferSelect) | undefined>;
  updateQuestion(id: number, updates: Partial<typeof questions.$inferSelect>): Promise<typeof questions.$inferSelect>;
}

export class DatabaseStorage implements IStorage {
  // Interviews
  async createInterview(interview: InsertInterview) {
    const [newInterview] = await db.insert(interviews).values(interview).returning();
    return newInterview;
  }

  async getInterview(id: number) {
    const [interview] = await db.select().from(interviews).where(eq(interviews.id, id));
    return interview;
  }

  async getUserInterviews(userId: string) {
    return db
      .select()
      .from(interviews)
      .where(eq(interviews.userId, userId))
      .orderBy(desc(interviews.createdAt));
  }

  async updateInterview(id: number, updates: Partial<typeof interviews.$inferSelect>) {
    const [updated] = await db
      .update(interviews)
      .set(updates)
      .where(eq(interviews.id, id))
      .returning();
    return updated;
  }

  // Questions
  async createQuestion(question: InsertQuestion) {
    const [newQuestion] = await db.insert(questions).values(question).returning();
    return newQuestion;
  }

  async getQuestionsByInterviewId(interviewId: number) {
    return db
      .select()
      .from(questions)
      .where(eq(questions.interviewId, interviewId))
      .orderBy(questions.order);
  }

  async getQuestion(id: number) {
    const [question] = await db.select().from(questions).where(eq(questions.id, id));
    return question;
  }

  async updateQuestion(id: number, updates: Partial<typeof questions.$inferSelect>) {
    const [updated] = await db
      .update(questions)
      .set(updates)
      .where(eq(questions.id, id))
      .returning();
    return updated;
  }
}

export const storage = new DatabaseStorage();
